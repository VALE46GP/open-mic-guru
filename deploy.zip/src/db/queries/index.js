const { eventQueries } = require('./events')
const { userQueries } = require('./users');

module.exports = {
    eventQueries,
    userQueries
};